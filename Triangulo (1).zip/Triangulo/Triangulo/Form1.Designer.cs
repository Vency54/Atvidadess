﻿namespace Triangulo
{
    partial class Form1
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            label2 = new Label();
            label3 = new Label();
            txtLado1 = new TextBox();
            txtLado2 = new TextBox();
            txtLado3 = new TextBox();
            btnClassificar = new Button();
            label4 = new Label();
            txtTipo = new TextBox();
            btnLimpar = new Button();
            btnSair = new Button();
            pbTriangulo = new PictureBox();
            ((System.ComponentModel.ISupportInitialize)pbTriangulo).BeginInit();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Location = new Point(18, 26);
            label1.Name = "label1";
            label1.Size = new Size(57, 21);
            label1.TabIndex = 0;
            label1.Text = "Lado 1";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Location = new Point(120, 26);
            label2.Name = "label2";
            label2.Size = new Size(57, 21);
            label2.TabIndex = 1;
            label2.Text = "Lado 2";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Location = new Point(229, 26);
            label3.Name = "label3";
            label3.Size = new Size(57, 21);
            label3.TabIndex = 2;
            label3.Text = "Lado 3";
            // 
            // txtLado1
            // 
            txtLado1.Location = new Point(18, 62);
            txtLado1.Name = "txtLado1";
            txtLado1.Size = new Size(70, 29);
            txtLado1.TabIndex = 3;
            txtLado1.TextChanged += txtLado1_TextChanged;
            txtLado1.KeyPress += txtLado1_KeyPress;
            // 
            // txtLado2
            // 
            txtLado2.Location = new Point(120, 62);
            txtLado2.Name = "txtLado2";
            txtLado2.Size = new Size(73, 29);
            txtLado2.TabIndex = 4;
            txtLado2.TextChanged += txtLado2_TextChanged;
            txtLado2.KeyPress += txtLado1_KeyPress;
            // 
            // txtLado3
            // 
            txtLado3.Location = new Point(229, 62);
            txtLado3.Name = "txtLado3";
            txtLado3.Size = new Size(70, 29);
            txtLado3.TabIndex = 5;
            txtLado3.TextChanged += txtLado3_TextChanged;
            txtLado3.KeyPress += txtLado1_KeyPress;
            // 
            // btnClassificar
            // 
            btnClassificar.Location = new Point(18, 106);
            btnClassificar.Name = "btnClassificar";
            btnClassificar.Size = new Size(279, 42);
            btnClassificar.TabIndex = 6;
            btnClassificar.Text = "Classificar";
            btnClassificar.UseVisualStyleBackColor = true;
            btnClassificar.Click += btnClassificar_Click;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Location = new Point(18, 175);
            label4.Name = "label4";
            label4.Size = new Size(40, 21);
            label4.TabIndex = 7;
            label4.Text = "Tipo";
            // 
            // txtTipo
            // 
            txtTipo.Location = new Point(102, 172);
            txtTipo.Name = "txtTipo";
            txtTipo.Size = new Size(195, 29);
            txtTipo.TabIndex = 8;
            // 
            // btnLimpar
            // 
            btnLimpar.Location = new Point(24, 233);
            btnLimpar.Name = "btnLimpar";
            btnLimpar.Size = new Size(85, 35);
            btnLimpar.TabIndex = 9;
            btnLimpar.Text = "Limpar";
            btnLimpar.UseVisualStyleBackColor = true;
            btnLimpar.Click += btnLimpar_Click;
            // 
            // btnSair
            // 
            btnSair.Location = new Point(205, 237);
            btnSair.Name = "btnSair";
            btnSair.Size = new Size(92, 31);
            btnSair.TabIndex = 10;
            btnSair.Text = "Sair";
            btnSair.UseVisualStyleBackColor = true;
            // 
            // pbTriangulo
            // 
            pbTriangulo.Image = Properties.Resources.isosceles;
            pbTriangulo.Location = new Point(339, 34);
            pbTriangulo.Name = "pbTriangulo";
            pbTriangulo.Size = new Size(240, 234);
            pbTriangulo.SizeMode = PictureBoxSizeMode.StretchImage;
            pbTriangulo.TabIndex = 11;
            pbTriangulo.TabStop = false;
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(9F, 21F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(598, 295);
            Controls.Add(pbTriangulo);
            Controls.Add(btnSair);
            Controls.Add(btnLimpar);
            Controls.Add(txtTipo);
            Controls.Add(label4);
            Controls.Add(btnClassificar);
            Controls.Add(txtLado3);
            Controls.Add(txtLado2);
            Controls.Add(txtLado1);
            Controls.Add(label3);
            Controls.Add(label2);
            Controls.Add(label1);
            Font = new Font("Segoe UI", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            Margin = new Padding(4);
            Name = "Form1";
            Text = "Form1";
            Load += Form1_Load;
            ((System.ComponentModel.ISupportInitialize)pbTriangulo).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label label1;
        private Label label2;
        private Label label3;
        private TextBox txtLado1;
        private TextBox txtLado2;
        private TextBox txtLado3;
        private Button btnClassificar;
        private Label label4;
        private TextBox txtTipo;
        private Button btnLimpar;
        private Button btnSair;
        private PictureBox pbTriangulo;
    }
}
