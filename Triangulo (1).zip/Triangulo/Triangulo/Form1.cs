namespace Triangulo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnClassificar_Click(object sender, EventArgs e)
        {
            double lado1, lado2, lado3;
            lado1 = double.Parse(txtLado1.Text);
            lado2 = double.Parse(txtLado2.Text);
            lado3 = double.Parse(txtLado3.Text);
            //verifico se � um tri�ngulo
            if (lado1 < lado2 + lado3 && lado2 < lado1 + lado3 && lado3 < lado1 + lado2)
            {
                //� um tri�ngulo, classifico
                //verifico se tem tr�s lados iguais
                if (lado1 == lado2 && lado2 == lado3)
                {
                    txtTipo.Text = "Equil�tero";
                    pbTriangulo.Image = Properties.Resources.equilatero;
                }
                else if (lado1 == lado2 || lado2 == lado3 || lado1 == lado3)
                {
                    txtTipo.Text = "Is�sceles";
                    pbTriangulo.Image = Properties.Resources.isosceles;
                }
                else
                {
                    txtTipo.Text = "Escaleno";
                    pbTriangulo.Image = Properties.Resources.escaleno;
                }
            }
            else
            {
                txtTipo.Text = "N�o � Tri�ngulo";
                pbTriangulo.Image = Properties.Resources.erro;
            }

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            pbTriangulo.Image = null;
            btnClassificar.Enabled = false;
            txtTipo.ReadOnly = false;
        }

        public void TestarCampos()
        {
            if (txtLado1.Text != "" && txtLado2.Text != "" & txtLado3.Text != "")
                btnClassificar.Enabled = true;
            else
                btnClassificar.Enabled = false;
        }

        private void txtLado1_TextChanged(object sender, EventArgs e)
        {
            TestarCampos();
        }

        private void txtLado2_TextChanged(object sender, EventArgs e)
        {
            TestarCampos();
        }

        private void txtLado3_TextChanged(object sender, EventArgs e)
        {
            TestarCampos();
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            txtLado1.Text = string.Empty;
            txtLado2.Text = string.Empty;
            txtLado3.Text = string.Empty;
            txtLado1.Focus();
            pbTriangulo.Image = null;
        }

        private void txtLado1_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(char.IsDigit(e.KeyChar) || char.IsControl(e.KeyChar))
                { 
                e.Handled = false; 
            }
            else if (e.KeyChar == ',')
            {
                var tb = (TextBox)sender;
                //impede mais de uma v�rgula
                if(tb.Text.Contains(","))
                    e.Handled = true;
                else
                    e.Handled |= false; // aceita a primeira v�rgula
            }
            else
            { e.Handled = true; }
               
        }
    }
}
