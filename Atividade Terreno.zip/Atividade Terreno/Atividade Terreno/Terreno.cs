﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade_Terreno
{
    public class Terreno
    {
        private double frente;
        private double lateral;
        private int lote;
        private string quadra;
        private int tipo;
        private string bairro;


        public double Frente
        {
            get { return frente; }
            set { frente = value; }
        }

        public double Lateral
        {
            get { return lateral; }
            set { lateral = value; }
        }

        public int Lote
        {
            get { return lote; }
            set { lote = value; }
        }

        public string Quadra
        {
            get { return quadra; }
            set { quadra = value; }
        }

        public int Tipo
        {
            get { return tipo; }
            set { tipo = value; }
        }

        public string Bairro
        {
            get { return bairro; }
            set { bairro = value; }
        }

        public double CalcularArea()
        {
            return frente * lateral;
        }

        public double CalcularPerimetro()
        {
            return 2 * (frente + lateral);
        }

        public double IPTU()
        {
            if (tipo == 1) { return (frente * lateral) * 0.50; }
            else { return (frente * lateral) * 1.50; }
        }

        public Terreno()
        {
            frente = 10;
            lateral = 25;
            lote = 0;
            quadra = " ";
            tipo = 1;
            bairro = "Não Informado";
        }
    }
}
