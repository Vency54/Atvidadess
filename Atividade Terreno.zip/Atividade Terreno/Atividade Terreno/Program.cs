﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Atividade_Terreno
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Terreno T = new Terreno();
        
            Console.WriteLine("Frente: {0}", T.Frente.ToString());
            Console.WriteLine("Lateral: {0}", T.Lateral.ToString());
            Console.WriteLine("Lote: {0}", T.Lote.ToString());
            Console.WriteLine("Quadra: {0}", T.Quadra.ToString());
            Console.WriteLine("Tipo: {0}", T.Tipo.ToString());
            Console.WriteLine("Bairro: {0}", T.Bairro.ToString());
            Console.WriteLine("Area: {0}", T.CalcularArea().ToString("N2"));
            Console.WriteLine("Perimetro: {0}", T.CalcularPerimetro().ToString("N2"));
            Console.WriteLine("IPTU: {0}", T.IPTU().ToString("N2"));
        }
    }
}
