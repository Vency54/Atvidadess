namespace IMC
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

       
        private void btnLimpar_Click(object sender, EventArgs e)
        {
            //tr�s maneiras diferentes de "limpar" um textbox
            txtAltura.Text = "";
            txtPeso.Text = string.Empty;
            txtIMC.Clear();
            txtClassificacao.Clear();
            //retorno o cursor para leitura de novo peso
            //o "foco" vai para o txtpeso
            txtPeso.Focus();

        }

        private void btnCalcular_Click(object sender, EventArgs e)
        {
            //declara��o de variaveis
            double peso, altura, imc;
            peso = double.Parse(txtPeso.Text);
            altura = double.Parse(txtAltura.Text);
            //c�lculo do IMC
            imc = peso / (altura * altura);
            //exibir o IMC
            txtIMC.Text = imc.ToString("N1");
            //exibir classifica��o de acordo com o valor do IMC
            if (imc < 20)
                txtClassificacao.Text = "magro";
            else
                if (imc <= 25)
                txtClassificacao.Text = "peso normal";
            else
                txtClassificacao.Text = "obeso";


        }

        private void btnCalcular_MouseEnter(object sender, EventArgs e)
        {
            
        }

        private void Form1_MouseEnter(object sender, EventArgs e)
        {
           
        }

        private void Form1_Load(object sender, EventArgs e)
         {
            txtIMC.ReadOnly = true;
            txtClassificacao.ReadOnly = true;
            btnCalcular.Enabled = false;

        }

        private void txtPeso_TextChanged(object sender, EventArgs e)
        {
            btnCalcular.Enabled = TestarCampos();
        }

        

        private void txtAltura_TextChanged(object sender, EventArgs e)
        {
            btnCalcular.Enabled = TestarCampos();
        }
        private bool TestarCampos()
        {
            if (txtPeso.Text != "" && txtAltura.Text != "")
                return true;
            else
                return false;
        }

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Deseja Sair?", "Sair do Sistema",
                            MessageBoxButtons.YesNo,
                            MessageBoxIcon.Question,
                            MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                Application.Exit();
        }
    }
}
