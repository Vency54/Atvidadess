﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace Academia
{
    public partial class frmAcademia : Form
    {
        int Cortesia = 0;
        double valor = 0;
            
        public frmAcademia()
        {
            InitializeComponent();
        }

        private void frmAcademia_Load(object sender, EventArgs e)
        {
            txtNome.CharacterCasing = CharacterCasing.Upper;
            txtEmail.CharacterCasing = CharacterCasing.Lower;
            lstDisponiveis.Sorted = true;
            lstSelecionados.Sorted = true;
            Inicializar();

        }
        private void Inicializar()
        {
            txtNome.Clear();
            txtEmail.Clear();
            rbManha.Checked = false;
            rbTarde.Checked = false;
            rbNoite.Checked = false;
            chkCromoterapia.Checked = false;
            chkFengShui.Checked = false;
            chkMeditacao.Checked = false;
            chkTaiChiChuan.Checked = false;
            chkYoga.Checked = false;
            grpModalidades.Enabled = false;
            grpCortesia.Enabled = false;

            lstDisponiveis.Items.Clear();
            lstSelecionados.Items.Clear();
            lstDisponiveis.Items.Add("Musculação");
            lstDisponiveis.Items.Add("Natação");
            lstDisponiveis.Items.Add("Zumba");
            lstDisponiveis.Items.Add("Pilates");
            lstDisponiveis.Items.Add("RPM");
            lstDisponiveis.Items.Add("Ginástica Ritmica");
            lstDisponiveis.Items.Add("Hidroginástica");
            lstDisponiveis.Items.Add("Patinação");
            lstDisponiveis.Items.Add("Squash");
           
            valor = 0;
            Cortesia = 0;
            TestarSelecao();
        }
        private void TestaCampos()
        {
            if (txtNome.Text != string.Empty && txtEmail.Text != string.Empty && (rbManha.Checked || rbTarde.Checked || rbNoite.Checked))
            {
                grpModalidades.Enabled = true;
                grpCortesia.Enabled = true;
            }
            else
            {
                grpModalidades.Enabled = false;
                grpCortesia.Enabled = false;
            }
        }

        private void txtNome_TextChanged(object sender, EventArgs e)
        {
            TestaCampos();

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {
            TestaCampos();
        }

        private void rbManha_CheckedChanged(object sender, EventArgs e)
        {
            TestaCampos();
            if (valor > 0) TestarSelecao();
        }

        private void rbTarde_CheckedChanged(object sender, EventArgs e)
        {
            TestaCampos();
            if (valor > 0) TestarSelecao();
            
        }

        private void rbNoite_CheckedChanged(object sender, EventArgs e)
        {
            TestaCampos();
            if (valor > 0) TestarSelecao();
        }

        private void btnSelecionarUm_Click(object sender, EventArgs e)
        {
            if (lstDisponiveis.SelectedIndex > -1)
            {
                lstSelecionados.Items.Add(lstDisponiveis.SelectedItem);
                lstDisponiveis.Items.Remove(lstDisponiveis.SelectedItem);
                TestarSelecao();
            }
            else
            {
                MessageBox.Show("É necessário Selecionar um item", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnSelecionarTodos_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstDisponiveis.Items.Count; i++)
            {
                lstSelecionados.Items.Add(lstDisponiveis.Items[i]);
            }
            lstDisponiveis.Items.Clear();
            TestarSelecao();
        }

        private void btnRecuperarUm_Click(object sender, EventArgs e)
        {
            if (lstSelecionados.SelectedIndex > -1)
            {
                lstDisponiveis.Items.Add(lstSelecionados.SelectedItem);
                lstSelecionados.Items.Remove(lstSelecionados.SelectedItem);
                TestarSelecao();
            }
            else
            {
                MessageBox.Show("É necessário Selecionar um item", "Erro", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }


        }

        private void btnRecuperarTodos_Click(object sender, EventArgs e)
        {
            for (int i = 0; i < lstSelecionados.Items.Count; i++)
            {
                lstDisponiveis.Items.Add(lstSelecionados.Items[i]);
            }
            lstSelecionados.Items.Clear();
            TestarSelecao();
        }

        private void TestarSelecao()
        {
            int Selecionados = lstSelecionados.Items.Count;
            int Disponiveis = lstDisponiveis.Items.Count;
            btnSelecionarUm.Enabled = Disponiveis > 0;
            btnSelecionarTodos.Enabled = Disponiveis > 0;
            btnRecuperarUm.Enabled  = Selecionados > 0;
            btnRecuperarTodos.Enabled = Selecionados > 0;

           
            txtQuantidade.Text = Selecionados.ToString();

             if (Selecionados != 0)
             {
                 if (Selecionados < 3)
                     valor = 100;
                 else if (Selecionados < 5)
                     valor = 150;
                 else if (Selecionados < 7)
                     valor = 200;
                 else
                     valor = 250;
             }


             if (rbTarde.Checked)
                 valor = valor * 0.85;

             txtValor.Text = valor.ToString("N2");
        }

       
        private void chkYoga_CheckedChanged(object sender, EventArgs e)
        {
            if (chkYoga.Checked)
                Cortesia += 1;
            else
                Cortesia -= 1;
            testarCortesia();
           
        }

        private void chkMeditacao_CheckedChanged(object sender, EventArgs e)
        {
            
            if (chkMeditacao.Checked)
                Cortesia += 1;
                                    
               
            else
                Cortesia -= 1;

            testarCortesia();
            
        }

        private void chkTaiChiChuan_CheckedChanged(object sender, EventArgs e)
        {
            if (chkTaiChiChuan.Checked)
                Cortesia += 1;
            else
                Cortesia -= 1;
            testarCortesia();
            
        }

        private void chkFengShui_CheckedChanged(object sender, EventArgs e)
        {
            if (chkFengShui.Checked)
                Cortesia += 1;
            else
                Cortesia -= 1;
            testarCortesia();
            
        }

        private void chkCromoterapia_CheckedChanged(object sender, EventArgs e)
        {
            if (chkCromoterapia.Checked)
                Cortesia += 1;
            else
                Cortesia -= 1;
            testarCortesia();
            
        }

        private void btnLimpar_Click(object sender, EventArgs e)
        {
            Inicializar();
            txtNome.Focus();
        }

        

        private void btnSair_Click(object sender, EventArgs e)
        {
            if (MessageBox.Show("Confirma Saída?", "Sair", MessageBoxButtons.YesNo, MessageBoxIcon.Question) == System.Windows.Forms.DialogResult.Yes)
                Application.Exit();
        }

        void testarCortesia()
        {
            if (Cortesia >= 3)
            {
                chkCromoterapia.Enabled = chkCromoterapia.Checked;
                chkMeditacao.Enabled = chkMeditacao.Checked;
                chkTaiChiChuan.Enabled = chkTaiChiChuan.Checked;
                chkFengShui.Enabled = chkFengShui.Checked ;
                chkYoga.Enabled = chkYoga.Checked;

            }
            else
            {
                chkCromoterapia.Enabled = true;
                chkMeditacao.Enabled = true;
                chkTaiChiChuan.Enabled = true;
                chkFengShui.Enabled = true;
                chkYoga.Enabled = true;
            }
            txtCortesia.Text = Cortesia.ToString();
        }

    }
}
