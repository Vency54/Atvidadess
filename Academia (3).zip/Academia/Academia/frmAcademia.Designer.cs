﻿namespace Academia
{
    partial class frmAcademia
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstDisponiveis = new System.Windows.Forms.ListBox();
            this.lstSelecionados = new System.Windows.Forms.ListBox();
            this.btnSelecionarUm = new System.Windows.Forms.Button();
            this.btnRecuperarUm = new System.Windows.Forms.Button();
            this.btnSelecionarTodos = new System.Windows.Forms.Button();
            this.btnRecuperarTodos = new System.Windows.Forms.Button();
            this.pnlRodape = new System.Windows.Forms.Panel();
            this.btnLimpar = new System.Windows.Forms.Button();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.rbNoite = new System.Windows.Forms.RadioButton();
            this.rbTarde = new System.Windows.Forms.RadioButton();
            this.rbManha = new System.Windows.Forms.RadioButton();
            this.label1 = new System.Windows.Forms.Label();
            this.txtNome = new System.Windows.Forms.TextBox();
            this.txtEmail = new System.Windows.Forms.TextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.grpModalidades = new System.Windows.Forms.GroupBox();
            this.grpCortesia = new System.Windows.Forms.GroupBox();
            this.chkCromoterapia = new System.Windows.Forms.CheckBox();
            this.chkFengShui = new System.Windows.Forms.CheckBox();
            this.chkTaiChiChuan = new System.Windows.Forms.CheckBox();
            this.chkMeditacao = new System.Windows.Forms.CheckBox();
            this.chkYoga = new System.Windows.Forms.CheckBox();
            this.grpResumo = new System.Windows.Forms.GroupBox();
            this.txtCortesia = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.txtValor = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.txtQuantidade = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.picFoto = new System.Windows.Forms.PictureBox();
            this.btnSair = new System.Windows.Forms.Button();
            this.pnlRodape.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.grpModalidades.SuspendLayout();
            this.grpCortesia.SuspendLayout();
            this.grpResumo.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).BeginInit();
            this.SuspendLayout();
            // 
            // lstDisponiveis
            // 
            this.lstDisponiveis.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstDisponiveis.FormattingEnabled = true;
            this.lstDisponiveis.ItemHeight = 16;
            this.lstDisponiveis.Location = new System.Drawing.Point(9, 18);
            this.lstDisponiveis.Name = "lstDisponiveis";
            this.lstDisponiveis.Size = new System.Drawing.Size(159, 132);
            this.lstDisponiveis.TabIndex = 0;
            // 
            // lstSelecionados
            // 
            this.lstSelecionados.Font = new System.Drawing.Font("Verdana", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstSelecionados.FormattingEnabled = true;
            this.lstSelecionados.ItemHeight = 16;
            this.lstSelecionados.Location = new System.Drawing.Point(261, 18);
            this.lstSelecionados.Name = "lstSelecionados";
            this.lstSelecionados.Size = new System.Drawing.Size(159, 132);
            this.lstSelecionados.TabIndex = 1;
            // 
            // btnSelecionarUm
            // 
            this.btnSelecionarUm.Location = new System.Drawing.Point(188, 18);
            this.btnSelecionarUm.Name = "btnSelecionarUm";
            this.btnSelecionarUm.Size = new System.Drawing.Size(47, 23);
            this.btnSelecionarUm.TabIndex = 2;
            this.btnSelecionarUm.Text = ">";
            this.btnSelecionarUm.UseVisualStyleBackColor = true;
            this.btnSelecionarUm.Click += new System.EventHandler(this.btnSelecionarUm_Click);
            // 
            // btnRecuperarUm
            // 
            this.btnRecuperarUm.Location = new System.Drawing.Point(188, 53);
            this.btnRecuperarUm.Name = "btnRecuperarUm";
            this.btnRecuperarUm.Size = new System.Drawing.Size(47, 23);
            this.btnRecuperarUm.TabIndex = 3;
            this.btnRecuperarUm.Text = "<";
            this.btnRecuperarUm.UseVisualStyleBackColor = true;
            this.btnRecuperarUm.Click += new System.EventHandler(this.btnRecuperarUm_Click);
            // 
            // btnSelecionarTodos
            // 
            this.btnSelecionarTodos.Location = new System.Drawing.Point(188, 86);
            this.btnSelecionarTodos.Name = "btnSelecionarTodos";
            this.btnSelecionarTodos.Size = new System.Drawing.Size(47, 27);
            this.btnSelecionarTodos.TabIndex = 4;
            this.btnSelecionarTodos.Text = ">>";
            this.btnSelecionarTodos.UseVisualStyleBackColor = true;
            this.btnSelecionarTodos.Click += new System.EventHandler(this.btnSelecionarTodos_Click);
            // 
            // btnRecuperarTodos
            // 
            this.btnRecuperarTodos.Location = new System.Drawing.Point(188, 124);
            this.btnRecuperarTodos.Name = "btnRecuperarTodos";
            this.btnRecuperarTodos.Size = new System.Drawing.Size(47, 23);
            this.btnRecuperarTodos.TabIndex = 5;
            this.btnRecuperarTodos.Text = "<<";
            this.btnRecuperarTodos.UseVisualStyleBackColor = true;
            this.btnRecuperarTodos.Click += new System.EventHandler(this.btnRecuperarTodos_Click);
            // 
            // pnlRodape
            // 
            this.pnlRodape.Controls.Add(this.btnSair);
            this.pnlRodape.Controls.Add(this.btnLimpar);
            this.pnlRodape.Dock = System.Windows.Forms.DockStyle.Bottom;
            this.pnlRodape.Location = new System.Drawing.Point(0, 386);
            this.pnlRodape.Name = "pnlRodape";
            this.pnlRodape.Size = new System.Drawing.Size(650, 52);
            this.pnlRodape.TabIndex = 6;
            // 
            // btnLimpar
            // 
            this.btnLimpar.Location = new System.Drawing.Point(14, 8);
            this.btnLimpar.Name = "btnLimpar";
            this.btnLimpar.Size = new System.Drawing.Size(75, 41);
            this.btnLimpar.TabIndex = 1;
            this.btnLimpar.Text = "Limpar";
            this.btnLimpar.UseVisualStyleBackColor = true;
            this.btnLimpar.Click += new System.EventHandler(this.btnLimpar_Click);
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.rbNoite);
            this.groupBox1.Controls.Add(this.rbTarde);
            this.groupBox1.Controls.Add(this.rbManha);
            this.groupBox1.Location = new System.Drawing.Point(5, 88);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(436, 46);
            this.groupBox1.TabIndex = 7;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Período";
            // 
            // rbNoite
            // 
            this.rbNoite.AutoSize = true;
            this.rbNoite.Location = new System.Drawing.Point(369, 19);
            this.rbNoite.Name = "rbNoite";
            this.rbNoite.Size = new System.Drawing.Size(50, 17);
            this.rbNoite.TabIndex = 2;
            this.rbNoite.TabStop = true;
            this.rbNoite.Text = "Noite";
            this.rbNoite.UseVisualStyleBackColor = true;
            this.rbNoite.CheckedChanged += new System.EventHandler(this.rbNoite_CheckedChanged);
            // 
            // rbTarde
            // 
            this.rbTarde.AutoSize = true;
            this.rbTarde.Location = new System.Drawing.Point(200, 19);
            this.rbTarde.Name = "rbTarde";
            this.rbTarde.Size = new System.Drawing.Size(53, 17);
            this.rbTarde.TabIndex = 1;
            this.rbTarde.TabStop = true;
            this.rbTarde.Text = "Tarde";
            this.rbTarde.UseVisualStyleBackColor = true;
            this.rbTarde.CheckedChanged += new System.EventHandler(this.rbTarde_CheckedChanged);
            // 
            // rbManha
            // 
            this.rbManha.AutoSize = true;
            this.rbManha.Location = new System.Drawing.Point(16, 20);
            this.rbManha.Name = "rbManha";
            this.rbManha.Size = new System.Drawing.Size(58, 17);
            this.rbManha.TabIndex = 0;
            this.rbManha.TabStop = true;
            this.rbManha.Text = "Manhã";
            this.rbManha.UseVisualStyleBackColor = true;
            this.rbManha.CheckedChanged += new System.EventHandler(this.rbManha_CheckedChanged);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(18, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(38, 13);
            this.label1.TabIndex = 8;
            this.label1.Text = "Nome:";
            // 
            // txtNome
            // 
            this.txtNome.Location = new System.Drawing.Point(73, 26);
            this.txtNome.Name = "txtNome";
            this.txtNome.Size = new System.Drawing.Size(368, 20);
            this.txtNome.TabIndex = 9;
            this.txtNome.TextChanged += new System.EventHandler(this.txtNome_TextChanged);
            // 
            // txtEmail
            // 
            this.txtEmail.Location = new System.Drawing.Point(74, 52);
            this.txtEmail.Name = "txtEmail";
            this.txtEmail.Size = new System.Drawing.Size(367, 20);
            this.txtEmail.TabIndex = 11;
            this.txtEmail.TextChanged += new System.EventHandler(this.txtEmail_TextChanged);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(19, 55);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(35, 13);
            this.label2.TabIndex = 10;
            this.label2.Text = "Email:";
            // 
            // grpModalidades
            // 
            this.grpModalidades.Controls.Add(this.btnRecuperarTodos);
            this.grpModalidades.Controls.Add(this.btnSelecionarTodos);
            this.grpModalidades.Controls.Add(this.btnRecuperarUm);
            this.grpModalidades.Controls.Add(this.btnSelecionarUm);
            this.grpModalidades.Controls.Add(this.lstSelecionados);
            this.grpModalidades.Controls.Add(this.lstDisponiveis);
            this.grpModalidades.Location = new System.Drawing.Point(5, 140);
            this.grpModalidades.Name = "grpModalidades";
            this.grpModalidades.Size = new System.Drawing.Size(436, 169);
            this.grpModalidades.TabIndex = 12;
            this.grpModalidades.TabStop = false;
            this.grpModalidades.Text = "Modalidades";
            // 
            // grpCortesia
            // 
            this.grpCortesia.Controls.Add(this.chkCromoterapia);
            this.grpCortesia.Controls.Add(this.chkFengShui);
            this.grpCortesia.Controls.Add(this.chkTaiChiChuan);
            this.grpCortesia.Controls.Add(this.chkMeditacao);
            this.grpCortesia.Controls.Add(this.chkYoga);
            this.grpCortesia.Location = new System.Drawing.Point(447, 152);
            this.grpCortesia.Name = "grpCortesia";
            this.grpCortesia.Size = new System.Drawing.Size(191, 157);
            this.grpCortesia.TabIndex = 14;
            this.grpCortesia.TabStop = false;
            this.grpCortesia.Text = "Cortesia";
            // 
            // chkCromoterapia
            // 
            this.chkCromoterapia.AutoSize = true;
            this.chkCromoterapia.Location = new System.Drawing.Point(12, 116);
            this.chkCromoterapia.Name = "chkCromoterapia";
            this.chkCromoterapia.Size = new System.Drawing.Size(88, 17);
            this.chkCromoterapia.TabIndex = 4;
            this.chkCromoterapia.Text = "Cromoterapia";
            this.chkCromoterapia.UseVisualStyleBackColor = true;
            this.chkCromoterapia.CheckedChanged += new System.EventHandler(this.chkCromoterapia_CheckedChanged);
            // 
            // chkFengShui
            // 
            this.chkFengShui.AutoSize = true;
            this.chkFengShui.Location = new System.Drawing.Point(12, 93);
            this.chkFengShui.Name = "chkFengShui";
            this.chkFengShui.Size = new System.Drawing.Size(74, 17);
            this.chkFengShui.TabIndex = 3;
            this.chkFengShui.Text = "Feng Shui";
            this.chkFengShui.UseVisualStyleBackColor = true;
            this.chkFengShui.CheckedChanged += new System.EventHandler(this.chkFengShui_CheckedChanged);
            // 
            // chkTaiChiChuan
            // 
            this.chkTaiChiChuan.AutoSize = true;
            this.chkTaiChiChuan.Location = new System.Drawing.Point(12, 70);
            this.chkTaiChiChuan.Name = "chkTaiChiChuan";
            this.chkTaiChiChuan.Size = new System.Drawing.Size(93, 17);
            this.chkTaiChiChuan.TabIndex = 2;
            this.chkTaiChiChuan.Text = "Tai Chi Chuan";
            this.chkTaiChiChuan.UseVisualStyleBackColor = true;
            this.chkTaiChiChuan.CheckedChanged += new System.EventHandler(this.chkTaiChiChuan_CheckedChanged);
            // 
            // chkMeditacao
            // 
            this.chkMeditacao.AutoSize = true;
            this.chkMeditacao.Location = new System.Drawing.Point(12, 47);
            this.chkMeditacao.Name = "chkMeditacao";
            this.chkMeditacao.Size = new System.Drawing.Size(76, 17);
            this.chkMeditacao.TabIndex = 1;
            this.chkMeditacao.Text = "Meditação";
            this.chkMeditacao.UseVisualStyleBackColor = true;
            this.chkMeditacao.CheckedChanged += new System.EventHandler(this.chkMeditacao_CheckedChanged);
            // 
            // chkYoga
            // 
            this.chkYoga.AutoSize = true;
            this.chkYoga.Location = new System.Drawing.Point(12, 24);
            this.chkYoga.Name = "chkYoga";
            this.chkYoga.Size = new System.Drawing.Size(51, 17);
            this.chkYoga.TabIndex = 0;
            this.chkYoga.Text = "Yoga";
            this.chkYoga.UseVisualStyleBackColor = true;
            this.chkYoga.CheckedChanged += new System.EventHandler(this.chkYoga_CheckedChanged);
            // 
            // grpResumo
            // 
            this.grpResumo.Controls.Add(this.txtCortesia);
            this.grpResumo.Controls.Add(this.label6);
            this.grpResumo.Controls.Add(this.txtValor);
            this.grpResumo.Controls.Add(this.label5);
            this.grpResumo.Controls.Add(this.txtQuantidade);
            this.grpResumo.Controls.Add(this.label4);
            this.grpResumo.Location = new System.Drawing.Point(9, 322);
            this.grpResumo.Name = "grpResumo";
            this.grpResumo.Size = new System.Drawing.Size(629, 58);
            this.grpResumo.TabIndex = 15;
            this.grpResumo.TabStop = false;
            this.grpResumo.Text = "Resumo";
            // 
            // txtCortesia
            // 
            this.txtCortesia.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtCortesia.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCortesia.ForeColor = System.Drawing.Color.Red;
            this.txtCortesia.Location = new System.Drawing.Point(277, 19);
            this.txtCortesia.Name = "txtCortesia";
            this.txtCortesia.ReadOnly = true;
            this.txtCortesia.Size = new System.Drawing.Size(52, 20);
            this.txtCortesia.TabIndex = 7;
            this.txtCortesia.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(226, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(45, 13);
            this.label6.TabIndex = 6;
            this.label6.Text = "Cortesia";
            // 
            // txtValor
            // 
            this.txtValor.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtValor.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtValor.ForeColor = System.Drawing.Color.Red;
            this.txtValor.Location = new System.Drawing.Point(515, 19);
            this.txtValor.Name = "txtValor";
            this.txtValor.ReadOnly = true;
            this.txtValor.Size = new System.Drawing.Size(100, 20);
            this.txtValor.TabIndex = 5;
            this.txtValor.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(405, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(94, 13);
            this.label5.TabIndex = 4;
            this.label5.Text = "Valor a Pagar (R$)";
            // 
            // txtQuantidade
            // 
            this.txtQuantidade.BackColor = System.Drawing.SystemColors.ButtonHighlight;
            this.txtQuantidade.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtQuantidade.ForeColor = System.Drawing.Color.Red;
            this.txtQuantidade.Location = new System.Drawing.Point(78, 19);
            this.txtQuantidade.Name = "txtQuantidade";
            this.txtQuantidade.ReadOnly = true;
            this.txtQuantidade.Size = new System.Drawing.Size(100, 20);
            this.txtQuantidade.TabIndex = 3;
            this.txtQuantidade.TextAlign = System.Windows.Forms.HorizontalAlignment.Right;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(62, 13);
            this.label4.TabIndex = 2;
            this.label4.Text = "Quantidade";
            // 
            // picFoto
            // 
            this.picFoto.Image = global::Academia.Properties.Resources.jobs;
            this.picFoto.Location = new System.Drawing.Point(447, 12);
            this.picFoto.Name = "picFoto";
            this.picFoto.Size = new System.Drawing.Size(191, 134);
            this.picFoto.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picFoto.TabIndex = 13;
            this.picFoto.TabStop = false;
            // 
            // btnSair
            // 
            this.btnSair.Image = global::Academia.Properties.Resources.Log_Out_Icon_32;
            this.btnSair.Location = new System.Drawing.Point(112, 8);
            this.btnSair.Name = "btnSair";
            this.btnSair.Size = new System.Drawing.Size(75, 41);
            this.btnSair.TabIndex = 2;
            this.btnSair.UseVisualStyleBackColor = true;
            this.btnSair.Click += new System.EventHandler(this.btnSair_Click);
            // 
            // frmAcademia
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(650, 438);
            this.Controls.Add(this.grpResumo);
            this.Controls.Add(this.grpCortesia);
            this.Controls.Add(this.picFoto);
            this.Controls.Add(this.grpModalidades);
            this.Controls.Add(this.txtEmail);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.txtNome);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pnlRodape);
            this.Name = "frmAcademia";
            this.Text = "Academia XPTO";
            this.Load += new System.EventHandler(this.frmAcademia_Load);
            this.pnlRodape.ResumeLayout(false);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.grpModalidades.ResumeLayout(false);
            this.grpCortesia.ResumeLayout(false);
            this.grpCortesia.PerformLayout();
            this.grpResumo.ResumeLayout(false);
            this.grpResumo.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.picFoto)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ListBox lstDisponiveis;
        private System.Windows.Forms.ListBox lstSelecionados;
        private System.Windows.Forms.Button btnSelecionarUm;
        private System.Windows.Forms.Button btnRecuperarUm;
        private System.Windows.Forms.Button btnSelecionarTodos;
        private System.Windows.Forms.Button btnRecuperarTodos;
        private System.Windows.Forms.Panel pnlRodape;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.RadioButton rbNoite;
        private System.Windows.Forms.RadioButton rbTarde;
        private System.Windows.Forms.RadioButton rbManha;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtNome;
        private System.Windows.Forms.TextBox txtEmail;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.GroupBox grpModalidades;
        private System.Windows.Forms.PictureBox picFoto;
        private System.Windows.Forms.GroupBox grpCortesia;
        private System.Windows.Forms.CheckBox chkCromoterapia;
        private System.Windows.Forms.CheckBox chkFengShui;
        private System.Windows.Forms.CheckBox chkTaiChiChuan;
        private System.Windows.Forms.CheckBox chkMeditacao;
        private System.Windows.Forms.CheckBox chkYoga;
        private System.Windows.Forms.GroupBox grpResumo;
        private System.Windows.Forms.TextBox txtCortesia;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox txtValor;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.TextBox txtQuantidade;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button btnSair;
        private System.Windows.Forms.Button btnLimpar;
    }
}

